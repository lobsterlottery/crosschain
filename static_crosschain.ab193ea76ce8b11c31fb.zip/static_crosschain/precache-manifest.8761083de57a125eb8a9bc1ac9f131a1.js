self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8f9775b3ade1c36d3f92c7e587bf7b0a",
    "url": "./index.html"
  },
  {
    "revision": "737490e6f572fc717c69",
    "url": "./static/css/2.5aa401b8.chunk.css"
  },
  {
    "revision": "737490e6f572fc717c69",
    "url": "./static/js/2.d82ec9bf.chunk.js"
  },
  {
    "revision": "61e2429265f9e7e2eb44b00cb4d51d76",
    "url": "./static/js/2.d82ec9bf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "012b3886eaf4209b405096a9519e23ad",
    "url": "./static/js/2.d82ec9bf.chunk.js.gz"
  },
  {
    "revision": "30faa7fda388f52d834f",
    "url": "./static/js/3.111431aa.chunk.js"
  },
  {
    "revision": "d9e36ccbbbfdad3eab57cb8c988c6ace",
    "url": "./static/js/3.111431aa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "18c981291de0edfa2ca955fc96ee4bb3",
    "url": "./static/js/3.111431aa.chunk.js.gz"
  },
  {
    "revision": "d150b2ccdd0c81540d69",
    "url": "./static/js/4.c2b28118.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "./static/js/4.c2b28118.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6d1819abfc319c4d14129c10bc09deca",
    "url": "./static/js/4.c2b28118.chunk.js.gz"
  },
  {
    "revision": "07a5ae6c5b6c3395bca3",
    "url": "./static/js/main.2b5c0086.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "./static/js/main.2b5c0086.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2d80b9614cba5c45548a6164b1fc72f7",
    "url": "./static/js/main.2b5c0086.chunk.js.gz"
  },
  {
    "revision": "3a507ae566538d8b87ee",
    "url": "./static/js/runtime-main.7530a08f.js"
  },
  {
    "revision": "a156dbce5a5218f83e8348c4d318493f",
    "url": "./static/media/AME.a156dbce.png"
  },
  {
    "revision": "b799cbbb1a47dbb0a633984ab3c27003",
    "url": "./static/media/ANY.b799cbbb.svg"
  },
  {
    "revision": "5e03f2fac2e0a5d2603e103f6e5f4c78",
    "url": "./static/media/ARBITRUM.5e03f2fa.png"
  },
  {
    "revision": "671566427e8c235975c917d8bcbd2d6d",
    "url": "./static/media/ASTR.67156642.png"
  },
  {
    "revision": "71607864da1166d988b77af524b88efe",
    "url": "./static/media/AVAX.71607864.png"
  },
  {
    "revision": "34f97f010971c1c9c931e76b3fcdd770",
    "url": "./static/media/BNB.34f97f01.svg"
  },
  {
    "revision": "5324604feb7cbbc461e7be877662061c",
    "url": "./static/media/BitKeep.5324604f.png"
  },
  {
    "revision": "86ce41f98183ec2bc704afce45e6b50d",
    "url": "./static/media/BitKeep.86ce41f9.jpg"
  },
  {
    "revision": "c80c0ea854a5d318f2d52f126a1f0f65",
    "url": "./static/media/Coin98.c80c0ea8.png"
  },
  {
    "revision": "767311236d51727249c52288892cbd7b",
    "url": "./static/media/EDG.76731123.svg"
  },
  {
    "revision": "cec4ef9ab899029e5232de3c46aeffcc",
    "url": "./static/media/ETH.cec4ef9a.svg"
  },
  {
    "revision": "f0ab208059cc049e7740e8c5f3ac8e58",
    "url": "./static/media/FKW.f0ab2080.png"
  },
  {
    "revision": "1728b4c4d308f9f0562cffbd50a23a49",
    "url": "./static/media/FSN.1728b4c4.svg"
  },
  {
    "revision": "cd3c4b3e877e55b33148c91f0e630d07",
    "url": "./static/media/GNO.cd3c4b3e.png"
  },
  {
    "revision": "51d786bbc7fed889b9f4e1c4a6fd0867",
    "url": "./static/media/HBIT.51d786bb.png"
  },
  {
    "revision": "e9159272a6a69144c13a788b423336f3",
    "url": "./static/media/HT.e9159272.png"
  },
  {
    "revision": "661569afe57a38e1529a775a465da20b",
    "url": "./static/media/Inter-Black.661569af.woff2"
  },
  {
    "revision": "d0b121f3a9d3d88afdfd6902d31ee9a0",
    "url": "./static/media/Inter-Black.d0b121f3.woff"
  },
  {
    "revision": "a3cc36c89047d530522fc999a22cce54",
    "url": "./static/media/Inter-BlackItalic.a3cc36c8.woff2"
  },
  {
    "revision": "e3329b2b90e1f9bcafd4a36604215dc1",
    "url": "./static/media/Inter-BlackItalic.e3329b2b.woff"
  },
  {
    "revision": "444a7284663a3bc886683eb81450b294",
    "url": "./static/media/Inter-Bold.444a7284.woff2"
  },
  {
    "revision": "99a0d9a7e4c99c17bfdd94a22a5cf94e",
    "url": "./static/media/Inter-Bold.99a0d9a7.woff"
  },
  {
    "revision": "3aa31f7356ea9db132b3b2bd8a65df44",
    "url": "./static/media/Inter-BoldItalic.3aa31f73.woff"
  },
  {
    "revision": "96284e2a02af46d9ffa2d189eaad5483",
    "url": "./static/media/Inter-BoldItalic.96284e2a.woff2"
  },
  {
    "revision": "37da9eecf61ebced804b266b14eef98e",
    "url": "./static/media/Inter-ExtraBold.37da9eec.woff2"
  },
  {
    "revision": "ab70688a1c9d6525584b123575f6c0a5",
    "url": "./static/media/Inter-ExtraBold.ab70688a.woff"
  },
  {
    "revision": "728a4c7df3ed1b2bc077010063f9ef1c",
    "url": "./static/media/Inter-ExtraBoldItalic.728a4c7d.woff"
  },
  {
    "revision": "fcc7d60ef790b43eb520fdc5c7348799",
    "url": "./static/media/Inter-ExtraBoldItalic.fcc7d60e.woff2"
  },
  {
    "revision": "b3b2ed6a20c538e9c809f4df5c04ac2a",
    "url": "./static/media/Inter-ExtraLight.b3b2ed6a.woff2"
  },
  {
    "revision": "dd19efda9c6e88ad83a5b052915899f7",
    "url": "./static/media/Inter-ExtraLight.dd19efda.woff"
  },
  {
    "revision": "079cd1e71cd4f73bef86f72deced6d03",
    "url": "./static/media/Inter-ExtraLightItalic.079cd1e7.woff2"
  },
  {
    "revision": "a6566ae6fa3c58b48f888d7c9c234d52",
    "url": "./static/media/Inter-ExtraLightItalic.a6566ae6.woff"
  },
  {
    "revision": "f137a90d649b6ab032563856df323f40",
    "url": "./static/media/Inter-Italic.f137a90d.woff"
  },
  {
    "revision": "fd26ff23f831db9ae85a805386529385",
    "url": "./static/media/Inter-Italic.fd26ff23.woff2"
  },
  {
    "revision": "5d3776eb78374b0ebbce639adadf73d1",
    "url": "./static/media/Inter-Light.5d3776eb.woff"
  },
  {
    "revision": "780dd2adb71f18d7a357ab7f65e881d6",
    "url": "./static/media/Inter-Light.780dd2ad.woff2"
  },
  {
    "revision": "d0fa7cbcf9ca5edb6ebe41fd8d49e1fb",
    "url": "./static/media/Inter-LightItalic.d0fa7cbc.woff"
  },
  {
    "revision": "df29c53403b2e13dc56df3e291c32f09",
    "url": "./static/media/Inter-LightItalic.df29c534.woff2"
  },
  {
    "revision": "75db5319e7e87c587019a5df08d7272c",
    "url": "./static/media/Inter-Medium.75db5319.woff2"
  },
  {
    "revision": "c0638bea87a05fdfa2bb3bba2efe54e4",
    "url": "./static/media/Inter-Medium.c0638bea.woff"
  },
  {
    "revision": "a1b588627dd12c556a7e3cd81e400ecf",
    "url": "./static/media/Inter-MediumItalic.a1b58862.woff"
  },
  {
    "revision": "f1e11535e56c67698e263673f625103e",
    "url": "./static/media/Inter-MediumItalic.f1e11535.woff2"
  },
  {
    "revision": "3ac83020fe53b617b79b5e2ad66764af",
    "url": "./static/media/Inter-Regular.3ac83020.woff"
  },
  {
    "revision": "dc131113894217b5031000575d9de002",
    "url": "./static/media/Inter-Regular.dc131113.woff2"
  },
  {
    "revision": "007ad31a53f4ab3f58ee74f2308482ce",
    "url": "./static/media/Inter-SemiBold.007ad31a.woff2"
  },
  {
    "revision": "66a68ffab2bf40553e847e8f025f75be",
    "url": "./static/media/Inter-SemiBold.66a68ffa.woff"
  },
  {
    "revision": "3031b683bafcd9ded070c00d784f4626",
    "url": "./static/media/Inter-SemiBoldItalic.3031b683.woff2"
  },
  {
    "revision": "6cd13dbd150ac0c7f337a2939a3d50a8",
    "url": "./static/media/Inter-SemiBoldItalic.6cd13dbd.woff"
  },
  {
    "revision": "b068b7189120a6626e3cfe2a8b917d0f",
    "url": "./static/media/Inter-Thin.b068b718.woff"
  },
  {
    "revision": "d52e5e38715502616522eb3e9963b69b",
    "url": "./static/media/Inter-Thin.d52e5e38.woff2"
  },
  {
    "revision": "97bec98832c92f799aeebf670b83ff6c",
    "url": "./static/media/Inter-ThinItalic.97bec988.woff"
  },
  {
    "revision": "a9780071b7f498c1523602910a5ef242",
    "url": "./static/media/Inter-ThinItalic.a9780071.woff2"
  },
  {
    "revision": "1f7ca6383ea7c74a7f5ddd76c3d3cef2",
    "url": "./static/media/Inter-italic.var.1f7ca638.woff2"
  },
  {
    "revision": "66c6e40883646a7ad993108b2ce2da32",
    "url": "./static/media/Inter-roman.var.66c6e408.woff2"
  },
  {
    "revision": "8dd26c3dd0125fb16ce19b8f5e8273fb",
    "url": "./static/media/Inter.var.8dd26c3d.woff2"
  },
  {
    "revision": "eef5a9d933d133e20835fc09ee3f6941",
    "url": "./static/media/KCC.eef5a9d9.svg"
  },
  {
    "revision": "d76026332ab774138b035658aa615a74",
    "url": "./static/media/KEK.d7602633.png"
  },
  {
    "revision": "35e6d0a293ecca433e33ea5bb138afb9",
    "url": "./static/media/Next.35e6d0a2.svg"
  },
  {
    "revision": "bcedbb05ad8577c5bf291d971900edf3",
    "url": "./static/media/OETH.bcedbb05.png"
  },
  {
    "revision": "f5c339b1bb8dcef2f1c674f67aa552f7",
    "url": "./static/media/OKT.f5c339b1.png"
  },
  {
    "revision": "d105013b609d30a476392e053b2261c8",
    "url": "./static/media/OPTIMISM.d105013b.svg"
  },
  {
    "revision": "2a8a3140b42e9e1dc0f76a8934a271ee",
    "url": "./static/media/PFSC.2a8a3140.svg"
  },
  {
    "revision": "91af12b13ff39bd1a247efa9f79b4f90",
    "url": "./static/media/Previous.91af12b1.svg"
  },
  {
    "revision": "858fd81170f75401ba9c700885919d34",
    "url": "./static/media/QR.858fd811.svg"
  },
  {
    "revision": "eae1a62f297e1b04c8e584c73e3fb621",
    "url": "./static/media/TERRA.eae1a62f.png"
  },
  {
    "revision": "72c18b7cc64f00cded245f26ff563347",
    "url": "./static/media/TRO.72c18b7c.png"
  },
  {
    "revision": "cec4ef9ab899029e5232de3c46aeffcc",
    "url": "./static/media/WETH.cec4ef9a.svg"
  },
  {
    "revision": "ebddd6cb66068f2e2f88238e2c59a596",
    "url": "./static/media/add-2-black.ebddd6cb.svg"
  },
  {
    "revision": "79917a4631d680f179f9bd3f30d9a157",
    "url": "./static/media/add-2-purpl.79917a46.svg"
  },
  {
    "revision": "41487eaa24f9a113dd658ee813688c4d",
    "url": "./static/media/add-2.41487eaa.svg"
  },
  {
    "revision": "33187bbf9c7a66e2ea499ed011b71065",
    "url": "./static/media/add-fff.33187bbf.svg"
  },
  {
    "revision": "773b56e0dfee6526da9b51bcaf868bae",
    "url": "./static/media/add-white.773b56e0.svg"
  },
  {
    "revision": "588fef4664c1eb3ec8e20a773efe53f2",
    "url": "./static/media/add.588fef46.svg"
  },
  {
    "revision": "4e5d58afbbfc1a5091d46261ebd23d4b",
    "url": "./static/media/address.4e5d58af.svg"
  },
  {
    "revision": "445698e956069b53bc4a31d127da6a0d",
    "url": "./static/media/any-illustration.445698e9.svg"
  },
  {
    "revision": "e795195748608c07b819004f5a39afcc",
    "url": "./static/media/any-purpl.e7951957.svg"
  },
  {
    "revision": "dcdfbd5ef15cd88e9c8782329b775991",
    "url": "./static/media/any.dcdfbd5e.svg"
  },
  {
    "revision": "cec4ef9ab899029e5232de3c46aeffcc",
    "url": "./static/media/anyETH.cec4ef9a.svg"
  },
  {
    "revision": "49e3c09436e382ca44a78b2f4202114b",
    "url": "./static/media/anyIcon.49e3c094.svg"
  },
  {
    "revision": "a8e15bd77ce761cc7180ae3a61f2f3b9",
    "url": "./static/media/anysSPELL.a8e15bd7.png"
  },
  {
    "revision": "5797650c600ee65de4394251fe487ba6",
    "url": "./static/media/application-purpl.5797650c.svg"
  },
  {
    "revision": "2c4580f169eca9b353a955fcdffb6a11",
    "url": "./static/media/application.2c4580f1.svg"
  },
  {
    "revision": "114fab910be089671a355764e2326334",
    "url": "./static/media/arrow-down-blue.114fab91.svg"
  },
  {
    "revision": "4d4a6a99f8bc24af0fcf805146d38a46",
    "url": "./static/media/arrow-down-grey.4d4a6a99.svg"
  },
  {
    "revision": "337ad716bd89163e2a9c3495b7e0f029",
    "url": "./static/media/arrow-right-white.337ad716.png"
  },
  {
    "revision": "e96d8158ff6d3087ab15e43e64fbb47e",
    "url": "./static/media/arrow-right.e96d8158.svg"
  },
  {
    "revision": "5b47c92eedfb4565c4cf69b835364838",
    "url": "./static/media/arrowDown.5b47c92e.svg"
  },
  {
    "revision": "41a34c45e747d836cf4e8bcd1d6b565c",
    "url": "./static/media/arrowRighr-purple.41a34c45.svg"
  },
  {
    "revision": "c1f1e8bc13ec92a74bb1635fa3bdfcda",
    "url": "./static/media/arrowRight.c1f1e8bc.svg"
  },
  {
    "revision": "cbc83a00262266a0f5dd5b8b15ebbad9",
    "url": "./static/media/arrowTopRight.cbc83a00.svg"
  },
  {
    "revision": "e62a99c33b7eafddf701893750cedeb9",
    "url": "./static/media/blue-loader.e62a99c3.svg"
  },
  {
    "revision": "f4c010e9807d956710b897f9c452258b",
    "url": "./static/media/bridge-gray.f4c010e9.svg"
  },
  {
    "revision": "a4f300605fa28af05c3021646fcdd72f",
    "url": "./static/media/bridge-purpl.a4f30060.svg"
  },
  {
    "revision": "c4bd3cf6b8a96fc70e927d0e0c55c053",
    "url": "./static/media/bridge-white-btn.c4bd3cf6.svg"
  },
  {
    "revision": "80f825fae8b3e4cf559e76a1e99729c1",
    "url": "./static/media/bridge-white.80f825fa.svg"
  },
  {
    "revision": "b3fea0e8d154f5533b66ba71e28cb3ad",
    "url": "./static/media/bridge.b3fea0e8.svg"
  },
  {
    "revision": "33c442cb73de39e1e29831355ac98c50",
    "url": "./static/media/bulb.33c442cb.svg"
  },
  {
    "revision": "17897e863859cefb3c539a34d4afea27",
    "url": "./static/media/check.17897e86.svg"
  },
  {
    "revision": "5dd950ec66be581e8da4376f49a19d77",
    "url": "./static/media/circle-grey.5dd950ec.svg"
  },
  {
    "revision": "716403ba670c3577abbea8e66f428721",
    "url": "./static/media/circle.716403ba.svg"
  },
  {
    "revision": "000d6316e8670e7833ca009b1dd38f1d",
    "url": "./static/media/code-white.000d6316.svg"
  },
  {
    "revision": "ea0f74957ad1a0443af655c9ae7bbca8",
    "url": "./static/media/code.ea0f7495.svg"
  },
  {
    "revision": "aa4c7a7647abc7ede02e017c1a0141b6",
    "url": "./static/media/coinbaseWalletIcon.aa4c7a76.svg"
  },
  {
    "revision": "db40de682ca1801ab63c8fb90c79a7bf",
    "url": "./static/media/create-exchange-purpl.db40de68.svg"
  },
  {
    "revision": "0d656631a745d815b41798d77b3b2f51",
    "url": "./static/media/create-exchange-white.0d656631.svg"
  },
  {
    "revision": "b7623604b034c4c7217624e6acce355d",
    "url": "./static/media/create-exchange.b7623604.svg"
  },
  {
    "revision": "08681d1df6f9c96b3f663a9b8743f39f",
    "url": "./static/media/day.08681d1d.svg"
  },
  {
    "revision": "0f8cd8bbafee1887f052e63e12299cb3",
    "url": "./static/media/deposit-purple.0f8cd8bb.svg"
  },
  {
    "revision": "6d55f1d5268d7c1ea5532667130b4bff",
    "url": "./static/media/deposit.6d55f1d5.svg"
  },
  {
    "revision": "fa3b400f26ae9b85bd9020e498103da9",
    "url": "./static/media/documents-purpl.fa3b400f.svg"
  },
  {
    "revision": "f1095363c23a61ca0e63e16f85a694e5",
    "url": "./static/media/documents.f1095363.svg"
  },
  {
    "revision": "cac6a7e6ec6dcf4900062f7bda6f9d4d",
    "url": "./static/media/done.cac6a7e6.svg"
  },
  {
    "revision": "80a3ae258c229f3c874a8acdf65adeea",
    "url": "./static/media/dropdown-blue.80a3ae25.svg"
  },
  {
    "revision": "50dbd07d8e7428d04464644f7cf819cf",
    "url": "./static/media/dropdown.50dbd07d.svg"
  },
  {
    "revision": "345dad7494f835eb9ae6c21c2d3a25f4",
    "url": "./static/media/dropup-blue.345dad74.svg"
  },
  {
    "revision": "0e5de0562189bcb69cc57fc52d9f839c",
    "url": "./static/media/edit.0e5de056.svg"
  },
  {
    "revision": "0bda443132779a5189c0ae1e457f9957",
    "url": "./static/media/explorer.0bda4431.svg"
  },
  {
    "revision": "66fb82f86bbf951a596cb4ec5628fe44",
    "url": "./static/media/github-white.66fb82f8.png"
  },
  {
    "revision": "59273cb4f80982519a80f09ed951c44e",
    "url": "./static/media/github.59273cb4.png"
  },
  {
    "revision": "bab0668aac5d1336dde12c4412d4d70c",
    "url": "./static/media/graph-up.bab0668a.svg"
  },
  {
    "revision": "3d1f749d68a70652fbaf94773bb86ad7",
    "url": "./static/media/inventory.3d1f749d.svg"
  },
  {
    "revision": "f3ea9f79a559836666d3da21a28f0e38",
    "url": "./static/media/lightcircle.f3ea9f79.svg"
  },
  {
    "revision": "50c67f3cdd04281013ef95e92fc7244e",
    "url": "./static/media/link.50c67f3c.svg"
  },
  {
    "revision": "04a2cb35e73b5bf99a540ae92984537c",
    "url": "./static/media/logo.04a2cb35.svg"
  },
  {
    "revision": "b842c71c4e839494f289670936c1284b",
    "url": "./static/media/logo_white.b842c71c.svg"
  },
  {
    "revision": "52eac682e8d399b4a8d1d48e38a60535",
    "url": "./static/media/magnifying-glass.52eac682.svg"
  },
  {
    "revision": "5c8aaf683d5552439c3da342c9c2ad7a",
    "url": "./static/media/markets-purpl.5c8aaf68.svg"
  },
  {
    "revision": "5666d3e38c77291c8b3178a682fe7ca1",
    "url": "./static/media/markets.5666d3e3.svg"
  },
  {
    "revision": "44739b395654a75af4d7a23d773715dd",
    "url": "./static/media/medium-white.44739b39.svg"
  },
  {
    "revision": "73608fa6f451f6a6c49b03f57d9b9e47",
    "url": "./static/media/medium.73608fa6.svg"
  },
  {
    "revision": "981ecca4e2e244ff635162cbb11b69ac",
    "url": "./static/media/menu.981ecca4.svg"
  },
  {
    "revision": "f95c1b67d8523a34a352aa6658e03e40",
    "url": "./static/media/metamask.f95c1b67.png"
  },
  {
    "revision": "5df3eef21f4957af1d26d49f6523d914",
    "url": "./static/media/mint-black.5df3eef2.svg"
  },
  {
    "revision": "a242fcadb1b9cca4d9fbe2c38ede0ba7",
    "url": "./static/media/mint.a242fcad.svg"
  },
  {
    "revision": "f1b94b14a51ec647bc72cfc8fdca0a91",
    "url": "./static/media/network-purpl.f1b94b14.svg"
  },
  {
    "revision": "0152b8bfb66d9cb70bdf29ddc75fa19a",
    "url": "./static/media/network-white.0152b8bf.svg"
  },
  {
    "revision": "1e8f5a66c4ee110a0b5c8ec7adffa05f",
    "url": "./static/media/network.1e8f5a66.svg"
  },
  {
    "revision": "31b3774a276f405fd9672b4f3e21915c",
    "url": "./static/media/night.31b3774a.svg"
  },
  {
    "revision": "376672e94989501bf8123c676d13e2c3",
    "url": "./static/media/no-coin.376672e9.svg"
  },
  {
    "revision": "13380dc0fc6becbd8c7d62012b5246dc",
    "url": "./static/media/paste.13380dc0.svg"
  },
  {
    "revision": "cc54bbc1e1a7e19f1245e7ec8da708bb",
    "url": "./static/media/path.cc54bbc1.svg"
  },
  {
    "revision": "899a4aa9bf85aba699112cc7cab6578e",
    "url": "./static/media/plus-blue.899a4aa9.svg"
  },
  {
    "revision": "62281ca8cea976c7f20862db5d12728e",
    "url": "./static/media/plus-grey.62281ca8.svg"
  },
  {
    "revision": "39e3c48b3b183e03629716560110406c",
    "url": "./static/media/pool-purpl.39e3c48b.svg"
  },
  {
    "revision": "463398de0d881f7e9dff37c84b4a1bae",
    "url": "./static/media/pool.463398de.svg"
  },
  {
    "revision": "b234b2bfa0417c7e8711c3a8d17afeec",
    "url": "./static/media/portisIcon.b234b2bf.png"
  },
  {
    "revision": "1761ff9cb139a2ba2a3a485172eb094c",
    "url": "./static/media/question-mark.1761ff9c.svg"
  },
  {
    "revision": "63be1e247274b62bc269445bf114d497",
    "url": "./static/media/question.63be1e24.svg"
  },
  {
    "revision": "094eb0cfd799bcfd94bf237fe6ad063c",
    "url": "./static/media/remove-black.094eb0cf.svg"
  },
  {
    "revision": "26e181483ee7085d741058af96e12256",
    "url": "./static/media/remove-purpl.26e18148.svg"
  },
  {
    "revision": "513f6e331c24fb94132b15afddea9419",
    "url": "./static/media/remove-white.513f6e33.svg"
  },
  {
    "revision": "31fa42b6481ff2b8e01202695410fe1e",
    "url": "./static/media/remove.31fa42b6.svg"
  },
  {
    "revision": "d6d04eda6b179cfe6032d46930d20696",
    "url": "./static/media/revert.d6d04eda.svg"
  },
  {
    "revision": "f1b94b14a51ec647bc72cfc8fdca0a91",
    "url": "./static/media/router.f1b94b14.svg"
  },
  {
    "revision": "a8e15bd77ce761cc7180ae3a61f2f3b9",
    "url": "./static/media/sSPELL.a8e15bd7.png"
  },
  {
    "revision": "1e335f3d7b34964b6928704c3b55842e",
    "url": "./static/media/schedule.1e335f3d.svg"
  },
  {
    "revision": "acd788c63cf401d1b7cd371db7c2961c",
    "url": "./static/media/search.acd788c6.svg"
  },
  {
    "revision": "54a0f9fec7e209513e09008bf1cebffb",
    "url": "./static/media/send-purpl.54a0f9fe.svg"
  },
  {
    "revision": "79dbcb4f65ee899a36d792c4ba59141c",
    "url": "./static/media/send-white.79dbcb4f.svg"
  },
  {
    "revision": "ddbf3e65cf409f9a3fa66f145feca597",
    "url": "./static/media/send.ddbf3e65.svg"
  },
  {
    "revision": "7e6c5f49628d8b0ae1b30f8c4842d813",
    "url": "./static/media/slippage.7e6c5f49.svg"
  },
  {
    "revision": "a98424922149274b8a364358d02da9fe",
    "url": "./static/media/spinner.a9842492.svg"
  },
  {
    "revision": "ccef365a883f2f10306c93664d36e54a",
    "url": "./static/media/swap-purpl.ccef365a.svg"
  },
  {
    "revision": "ce7af1209d9a415a0008a2da46202dfa",
    "url": "./static/media/swap-purple.ce7af120.svg"
  },
  {
    "revision": "7f60052ac9b6324825cabc8157dd0e87",
    "url": "./static/media/swap-white.7f60052a.svg"
  },
  {
    "revision": "55751d973b4623dcc008793b820d5f77",
    "url": "./static/media/swap.55751d97.svg"
  },
  {
    "revision": "d12a4612b7e45dae66e96845251d0289",
    "url": "./static/media/telegram-white.d12a4612.svg"
  },
  {
    "revision": "a86c2640fb08693e37c3904bbc4e4c9b",
    "url": "./static/media/telegram.a86c2640.svg"
  },
  {
    "revision": "edcc1ab5dde5cb3d5cf134c4aade641b",
    "url": "./static/media/trustWallet.edcc1ab5.png"
  },
  {
    "revision": "465e6ec8e2b62a1b4aed5dff1a21628d",
    "url": "./static/media/twitter-white.465e6ec8.svg"
  },
  {
    "revision": "f57bb357df843add1c8472a344509f6f",
    "url": "./static/media/twitter.f57bb357.svg"
  },
  {
    "revision": "9c1f279eeeea9626a7f74b389f92b42e",
    "url": "./static/media/unlock.9c1f279e.svg"
  },
  {
    "revision": "bc08a4ed66bc0c92b1200555ef99a690",
    "url": "./static/media/unlockBlack.bc08a4ed.svg"
  },
  {
    "revision": "b4209a9820b8eb121b85bd0d784ed6ad",
    "url": "./static/media/wallet.b4209a98.svg"
  },
  {
    "revision": "5e81cac236fd057cb686399a8fa2ea57",
    "url": "./static/media/walletConnectIcon.5e81cac2.svg"
  },
  {
    "revision": "25ca769cddb0602befc0d34cd741f1f7",
    "url": "./static/media/warning.25ca769c.svg"
  },
  {
    "revision": "dc25803e181e2901369020694c077fe9",
    "url": "./static/media/week.dc25803e.svg"
  },
  {
    "revision": "ba5f40901635e130130610fa64cbc17e",
    "url": "./static/media/withdraw-purple.ba5f4090.svg"
  },
  {
    "revision": "1c34f7c041f1b516f885bea7ce8993b8",
    "url": "./static/media/withdraw.1c34f7c0.svg"
  },
  {
    "revision": "5b8e218668bfea1d44b887bd042f6a52",
    "url": "./static/media/x.5b8e2186.svg"
  }
]);